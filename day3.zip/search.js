
const axios = require('axios');


const searchRecipes = async (searchTerm) => {
    try {
        const url = `https://api.spoonacular.com/recipes/complexSearch?apiKey=840042463d684471a5e6a85a37d26b95&query=${searchTerm}`;
        const res =  await axios.get(url);
        // console.log(res);
        return res.data;
    } catch (error) {
        console.log(error);
    }
}


// searchRecipes();
module.exports = searchRecipes;