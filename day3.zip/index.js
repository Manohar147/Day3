const searchRecipes = require('./search');


const loadRecipes = async (searchTerm) => {
    const data = await searchRecipes(searchTerm);
    const results = data.results;

    // const filtered = results.find(item => item.id == 658277 );

    console.log(results);
}

loadRecipes('chinese');